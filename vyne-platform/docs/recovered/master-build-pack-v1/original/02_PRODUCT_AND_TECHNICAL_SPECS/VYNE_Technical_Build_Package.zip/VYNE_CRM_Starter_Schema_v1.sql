-- VYNE CRM Starter Schema v1
-- Architectural starter only. Security, RLS, migrations, retention and regulatory requirements
-- must be finalized before production use.

create extension if not exists pgcrypto;

create type relationship_stage as enum (
  'subscriber','prospect','engaged_lead','intro_scheduled','qualified',
  'active_exploration','decision_pending','committed','transitioning','placed',
  'stay_strengthen','prepare_revisit','long_term_nurture','closed'
);
create type vyne_stage as enum (
  'understand','vision','objectives','readiness','navigate',
  'enterprise_economics','decide','execute','elevate','grow'
);
create type opportunity_stage as enum (
  'identified','advisor_approved','blind_check','submitted','firm_reviewing',
  'firm_interested','intro_scheduled','first_meeting_complete','due_diligence',
  'proposal_requested','proposal_received','advisor_reviewing','finalist','selected',
  'declined_by_advisor','declined_by_firm','on_hold','withdrawn'
);
create type confidence_level as enum ('verified','strong','provisional','conflicting','stale');
create type data_class as enum ('public','marketing_personal','advisor_confidential','book_analytics','client_restricted');
create type approval_status as enum ('draft','pending','approved','rejected','superseded');

create table organizations (
  id uuid primary key default gen_random_uuid(),
  organization_type text not null,
  legal_name text not null,
  display_name text,
  parent_id uuid references organizations(id),
  website text,
  crd_or_sec_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table people (
  id uuid primary key default gen_random_uuid(),
  first_name text not null,
  last_name text not null,
  preferred_name text,
  primary_email text,
  primary_phone text,
  crd_number text,
  current_organization_id uuid references organizations(id),
  verification_status text not null default 'unverified',
  verification_date timestamptz,
  data_class data_class not null default 'marketing_personal',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index people_crd_unique on people(crd_number) where crd_number is not null;
create index people_email_idx on people(lower(primary_email));

create table advisor_profiles (
  id uuid primary key default gen_random_uuid(),
  person_id uuid not null references people(id),
  effective_from date not null default current_date,
  effective_to date,
  t12_amount numeric(18,2),
  t12_is_range boolean not null default false,
  aum_amount numeric(20,2),
  aum_is_range boolean not null default false,
  household_count integer,
  recurring_revenue_pct numeric(5,2),
  self_built_pct numeric(5,2),
  years_in_industry numeric(5,1),
  team_size integer,
  practice_summary text,
  source_type text,
  source_document_id uuid,
  created_at timestamptz not null default now()
);
create index advisor_profiles_person_idx on advisor_profiles(person_id,effective_from desc);

create table relationships (
  id uuid primary key default gen_random_uuid(),
  advisor_person_id uuid not null references people(id),
  owner_person_id uuid references people(id),
  stage relationship_stage not null default 'prospect',
  lead_source text,
  primary_interest text,
  last_contact_at timestamptz,
  next_action_summary text,
  next_action_due_at timestamptz,
  closed_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index relationships_active_advisor_unique on relationships(advisor_person_id) where closed_reason is null;

create table cases (
  id uuid primary key default gen_random_uuid(),
  relationship_id uuid not null references relationships(id),
  case_type text not null,
  case_question text not null,
  stage vyne_stage not null default 'understand',
  status text not null default 'active',
  vision_summary text,
  readiness_status text,
  decision text,
  decision_date date,
  risk_level text,
  expected_fee_low numeric(18,2),
  expected_fee_high numeric(18,2),
  expected_decision_date date,
  expected_transition_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index cases_relationship_idx on cases(relationship_id,status);

create table case_objectives (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  category text not null,
  objective text not null,
  weight numeric(6,3),
  current_score numeric(5,2),
  minimum_score numeric(5,2),
  desired_score numeric(5,2),
  is_nonnegotiable boolean not null default false,
  client_impact numeric(5,2),
  advisor_impact numeric(5,2),
  team_impact numeric(5,2),
  enterprise_impact numeric(5,2),
  evidence text,
  created_at timestamptz not null default now()
);

create table firm_opportunities (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  firm_id uuid not null references organizations(id),
  stage opportunity_stage not null default 'identified',
  is_current_firm_option boolean not null default false,
  rationale text,
  key_strengths text,
  key_concerns text,
  advisor_interest numeric(5,2),
  firm_interest numeric(5,2),
  advisor_authorized_at timestamptz,
  submitted_at timestamptz,
  selected_at timestamptz,
  closed_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(case_id,firm_id)
);
create index firm_opportunities_stage_idx on firm_opportunities(stage,updated_at);

create table tasks (
  id uuid primary key default gen_random_uuid(),
  case_id uuid references cases(id) on delete cascade,
  opportunity_id uuid references firm_opportunities(id) on delete cascade,
  owner_person_id uuid references people(id),
  title text not null,
  description text,
  priority text not null default 'normal',
  due_at timestamptz,
  status text not null default 'open',
  completion_evidence text,
  completed_at timestamptz,
  created_at timestamptz not null default now()
);
create index tasks_open_due_idx on tasks(status,due_at) where status='open';

create table meetings (
  id uuid primary key default gen_random_uuid(),
  case_id uuid references cases(id) on delete cascade,
  opportunity_id uuid references firm_opportunities(id) on delete set null,
  meeting_type text not null,
  title text not null,
  objective text,
  scheduled_at timestamptz,
  completed_at timestamptz,
  location_or_link text,
  summary text,
  decisions text,
  open_questions text,
  followup_sent_at timestamptz,
  created_at timestamptz not null default now()
);

create table meeting_participants (
  meeting_id uuid not null references meetings(id) on delete cascade,
  person_id uuid not null references people(id),
  participant_role text,
  primary key(meeting_id,person_id)
);

create table documents (
  id uuid primary key default gen_random_uuid(),
  case_id uuid references cases(id) on delete cascade,
  opportunity_id uuid references firm_opportunities(id) on delete set null,
  document_type text not null,
  title text not null,
  version text,
  storage_key text not null,
  sha256 text,
  mime_type text,
  size_bytes bigint,
  data_class data_class not null,
  status approval_status not null default 'draft',
  uploaded_by uuid references people(id),
  reviewed_by uuid references people(id),
  reviewed_at timestamptz,
  supersedes_id uuid references documents(id),
  created_at timestamptz not null default now()
);

create table consents (
  id uuid primary key default gen_random_uuid(),
  person_id uuid not null references people(id),
  case_id uuid references cases(id),
  opportunity_id uuid references firm_opportunities(id),
  consent_type text not null,
  language_version text not null,
  scope jsonb not null default '{}'::jsonb,
  granted_at timestamptz not null,
  withdrawn_at timestamptz,
  evidence text,
  created_at timestamptz not null default now()
);

create table firm_intelligence_items (
  id uuid primary key default gen_random_uuid(),
  firm_id uuid not null references organizations(id),
  topic text not null,
  statement text not null,
  source_type text not null,
  source_reference text,
  source_document_id uuid references documents(id),
  effective_date date,
  observed_at timestamptz not null default now(),
  scope text,
  confidence confidence_level not null default 'provisional',
  visibility text not null default 'internal_only',
  review_due_date date,
  supersedes_id uuid references firm_intelligence_items(id),
  created_by uuid references people(id),
  approved_by uuid references people(id),
  approved_at timestamptz,
  created_at timestamptz not null default now()
);
create index firm_intel_firm_topic_idx on firm_intelligence_items(firm_id,topic,observed_at desc);

create table economic_models (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  opportunity_id uuid references firm_opportunities(id) on delete cascade,
  model_type text not null,
  version text not null,
  assumptions jsonb not null,
  outputs jsonb not null,
  source_documents uuid[] not null default '{}',
  status approval_status not null default 'draft',
  created_by uuid references people(id),
  reviewed_by uuid references people(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  unique(case_id,opportunity_id,model_type,version)
);

create table firm_agreements (
  id uuid primary key default gen_random_uuid(),
  firm_id uuid not null references organizations(id),
  agreement_name text not null,
  effective_from date not null,
  effective_to date,
  fee_terms jsonb not null,
  exclusions jsonb not null default '[]'::jsonb,
  clawback_terms jsonb not null default '{}'::jsonb,
  document_id uuid references documents(id),
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table placements (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id),
  opportunity_id uuid not null references firm_opportunities(id),
  firm_agreement_id uuid references firm_agreements(id),
  join_date date,
  verified_t12 numeric(18,2),
  verification_source text,
  fee_trigger_status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table fee_events (
  id uuid primary key default gen_random_uuid(),
  placement_id uuid not null references placements(id),
  event_type text not null,
  expected_amount numeric(18,2),
  actual_amount numeric(18,2),
  expected_date date,
  invoice_date date,
  due_date date,
  paid_date date,
  status text not null default 'forecast',
  calculation jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table assessments (
  id uuid primary key default gen_random_uuid(),
  person_id uuid references people(id),
  relationship_id uuid references relationships(id),
  assessment_type text not null,
  version text not null,
  answers jsonb not null,
  result jsonb not null,
  completed_at timestamptz not null default now()
);

create table portability_analyses (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id),
  version text not null,
  data_as_of_date date,
  data_scope text,
  assumptions jsonb not null,
  aggregate_results jsonb,
  status approval_status not null default 'draft',
  created_by uuid references people(id),
  reviewed_by uuid references people(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table portability_positions (
  id uuid primary key default gen_random_uuid(),
  analysis_id uuid not null references portability_analyses(id) on delete cascade,
  position_key text not null,
  account_category text,
  product_type text,
  security_identifier text,
  market_value numeric(20,2),
  annual_revenue numeric(18,2),
  lending_flag boolean,
  alternative_flag boolean,
  restricted_flag boolean,
  concentration_bucket text,
  classification_confidence numeric(5,4),
  raw_attributes jsonb not null default '{}'::jsonb,
  unique(analysis_id,position_key)
);

create table portability_results (
  id uuid primary key default gen_random_uuid(),
  analysis_id uuid not null references portability_analyses(id) on delete cascade,
  position_id uuid not null references portability_positions(id) on delete cascade,
  firm_id uuid not null references organizations(id),
  result text not null,
  rationale text,
  rule_source text,
  rule_effective_date date,
  confidence confidence_level not null default 'provisional',
  review_required boolean not null default true
);

create table continuity_opportunities (
  id uuid primary key default gen_random_uuid(),
  owner_person_id uuid not null references people(id),
  opportunity_type text not null,
  anonymous_title text not null,
  market text,
  practice_range jsonb,
  preferences jsonb not null default '{}'::jsonb,
  timing text,
  verification_status text not null default 'pending',
  publication_status text not null default 'private',
  created_at timestamptz not null default now()
);

create table continuity_matches (
  id uuid primary key default gen_random_uuid(),
  opportunity_a_id uuid not null references continuity_opportunities(id),
  opportunity_b_id uuid not null references continuity_opportunities(id),
  score numeric(6,3),
  rationale jsonb not null,
  status text not null default 'proposed',
  mutual_consent_at timestamptz,
  introduced_at timestamptz,
  outcome text,
  created_at timestamptz not null default now()
);

create table agent_runs (
  id uuid primary key default gen_random_uuid(),
  agent_name text not null,
  agent_version text not null,
  case_id uuid references cases(id),
  trigger_type text not null,
  input_record_ids jsonb not null default '[]'::jsonb,
  tool_permissions jsonb not null default '[]'::jsonb,
  model_provider text,
  model_name text,
  output_summary text,
  proposed_changes jsonb not null default '[]'::jsonb,
  approval_status approval_status not null default 'draft',
  approved_by uuid references people(id),
  approved_at timestamptz,
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  error_code text
);

create table audit_events (
  id bigserial primary key,
  occurred_at timestamptz not null default now(),
  actor_type text not null,
  actor_id text,
  action text not null,
  entity_type text,
  entity_id text,
  case_id uuid references cases(id),
  outcome text,
  metadata jsonb not null default '{}'::jsonb
);
create index audit_events_case_time_idx on audit_events(case_id,occurred_at desc);

-- Production work still required:
-- 1. Row-level security and tenant/role policies.
-- 2. updated_at triggers and immutable audit protections.
-- 3. Secure storage integration and malware scan status.
-- 4. Retention/deletion workflows and legal hold.
-- 5. Data encryption/key-management decisions.
-- 6. Migration tooling, backups, monitoring and performance tests.
