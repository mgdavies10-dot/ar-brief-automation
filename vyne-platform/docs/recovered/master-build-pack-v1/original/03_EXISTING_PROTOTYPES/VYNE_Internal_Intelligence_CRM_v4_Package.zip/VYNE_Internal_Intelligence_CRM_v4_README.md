# VYNE Internal Intelligence CRM v4

## What changed

This release extends the v3 local-browser prototype into a broader founder operating system.

### Finance and forecast
- Replaced probability-weighted forecast presentation with a full recorded forecast.
- Added a clean, single-line start calendar showing actual date, month/year, advisor or team, current firm, destination, T12, forecast fee, invoiced amount, and paid amount.
- Added calendar-year forecasts for future years, including 2027 and 2028 when records exist.
- Added dollar prefixes to annual planning-assumption fields.
- Added expense-ledger CSV export.
- Added consultant-commission forecasts and forecast revenue after commissions.

### Autosave
- Added a visible saved/saving indicator.
- Advisor command fields and finance assumptions are captured automatically.
- A forced save occurs every 30 seconds and before the browser closes.
- Existing explicit save actions continue to work.

### Advisor and team records
- Replaced visible TTMP terminology with T12.
- Added team records and a Team Command Page.
- New advisors can remain individual, join an existing team, or create a new team.
- Advisor pages display linked team members and provide a direct team-page link.
- Added clickable email actions on advisor records.
- Added the requested timing choices: no immediate timeline, immediately, 0–3, 3–6, 6–12, 12–24, and 24+ months.

### Meetings and call management
- Expanded meeting records to include date, time, location, firm, attendees, summary, full transcript, next steps, follow-up date, outcome, and attachments.
- Added detailed meeting-record review and editing.
- Added a meeting-preparation brief built from current case data, recent notes, firm opportunities, talking points, and unasked VYNE questions.

### Firm submissions
- Added the current firm and destination firm to the submission view.
- Added actual submission date, last firm meeting date, advisor impression, diligence notes, next action, and reason a firm was ruled out.
- Firm status remains separately editable for every advisor/firm opportunity.

### Command center and calendar
- Renamed “Pipeline by Claude status” to “Pipeline by status.”
- Expanded upcoming starts to show team members, current firm, destination, start date, T12, and invoice status.
- Added actual and projected hires by year.
- Added an internal monthly calendar for meetings, home-office/VIP visits, next actions, start dates, invoice events, payment dates, and annual placement anniversaries.

### Accounting and billing
- Added clickable firm-billing emails and invoice-email draft actions.
- Email actions create a draft with invoice details. Browsers cannot automatically attach the generated PDF, so the PDF must still be attached manually.
- Removed W-9 status from the active billing-profile form and invoice-facing presentation.

### Agent Center
- Added editable operating instructions for every agent: purpose, instructions, inputs, outputs, schedule, and approval rule.
- Human approval restrictions remain in place.

### Advisor-facing presentation
- Separated meeting preparation from advisor presentation.
- Added a presentation builder that allows the consultant to select the advisor-facing sections to display.
- Private notes, accounting, internal risk, and commissions are excluded.

### Users, assignments, and commissions
- Added a Team & Access area with users, roles, advisor ownership, and consultant commission percentages.
- Added a local role-view switcher.
- Non-administrator views are filtered to assigned advisor records on the primary dashboard, advisor directory, pipeline, and submissions.
- This is a workflow simulation only; it is not secure authentication or production authorization.

## Important limitations

This remains a single-file, local-browser prototype. It is not appropriate for real advisor, client, contract, invoice, or personnel data until the following are added:

- Server-side authentication and multi-factor authentication
- Enforced role-based and row-level permissions
- Encrypted database and file storage
- Immutable audit logs
- Backups and disaster recovery
- Secure document parsing and retention controls
- Server-side scheduled invoice generation
- Real email integration and attachment handling
- Calendar integration
- Accounting-system integration
- Legal, compliance, tax, and cybersecurity review

The invoice trigger continues to run only when the local application is open. The role switcher demonstrates the desired experience but does not prevent a knowledgeable user from accessing local browser data.
